﻿using System.Collections.Generic;
using System;
using System.Linq;

namespace StudentManagementSystem
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public List<int> Scores { get; set; }

        public Student(int id, string name, int age)
        {
            Id = id;
            Name = name;
            Age = age;
            Scores = new List<int>();
        }

        public double GetAverage()
        {
            return Scores.Count > 0 ? Scores.Average() : 0;
        }
    }

    public class StudentManager
    {
        private Dictionary<int, Student> students = new Dictionary<int, Student>();

        public void AddStudent(Student student)
        {
            if (students.ContainsKey(student.Id))
            {
                Console.WriteLine("이미 존재하는 학생입니다.");
                return;
            }
            students.Add(student.Id, student);
            Console.WriteLine($"{student.Name} 학생이 추가되었습니다.");
        }

        public Student FindStudent(int id)
        {
            if (students.TryGetValue(id, out Student student))
            {
                return student;
            }
            return null;
        }

        public void AddScore(int id, int score)
        {
            Student student = FindStudent(id);
            if (student != null)
            {
                student.Scores.Add(score);
                Console.WriteLine($"{student.Name}의 점수 {score}점이 추가되었습니다.");
            }
            else
            {
                Console.WriteLine("학생을 찾을 수 없습니다.");
            }
        }

        public List<Student> GetTopStudents(int count)
        {
            return students.Values
                           .OrderByDescending(s => s.GetAverage())
                           .Take(count)
                           .ToList();
        }

        public void PrintAllStudents()
        {
            Console.WriteLine("\n=== 전체 학생 목록 ===");
            foreach (var student in students.Values)
            {
                Console.WriteLine($"ID: {student.Id}, 이름: {student.Name}, " +
                                $"나이: {student.Age}, 평균: {student.GetAverage():F2}");
            }
        }
    }
    internal class MainApp
    {
        static void Main(string[] args)
        {
            StudentManager manager = new StudentManager();

            // 학생 추가
            manager.AddStudent(new Student(1, "홍길동", 20));
            manager.AddStudent(new Student(2, "김철수", 21));
            manager.AddStudent(new Student(3, "이영희", 20));

            // 점수 추가
            manager.AddScore(1, 85);
            manager.AddScore(1, 90);
            manager.AddScore(1, 78);

            manager.AddScore(2, 92);
            manager.AddScore(2, 88);
            manager.AddScore(2, 95);

            manager.AddScore(3, 78);
            manager.AddScore(3, 82);

            // 전체 출력
            manager.PrintAllStudents();

            // 상위 2명
            Console.WriteLine("\n=== 상위 2명 ===");
            List<Student> topStudents = manager.GetTopStudents(2);
            foreach (var student in topStudents)
            {
                Console.WriteLine($"{student.Name}: {student.GetAverage():F2}점");
            }
        }
    }
}
