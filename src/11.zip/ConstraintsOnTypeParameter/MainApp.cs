﻿using System;

namespace ConstraintsOnTypeParameter
{
    // ===============================
    // 1️⃣ 값 형식(struct) 제약
    // ===============================
    class StructArray<T> where T : struct
    {
        public T[] Array { get; set; }

        public StructArray(int size)
        {
            Array = new T[size];
            Console.WriteLine($"[StructArray<{typeof(T).Name}>] 생성됨 (크기 {size})");
        }
    }

    // ===============================
    // 2️⃣ 참조 형식(class) 제약
    // ===============================
    class RefArray<T> where T : class
    {
        public T[] Array { get; set; }

        public RefArray(int size)
        {
            Array = new T[size];
            Console.WriteLine($"[RefArray<{typeof(T).Name}>] 생성됨 (크기 {size})");
        }
    }

    // ===============================
    // 3️⃣ 상속 관계(Base 제약)
    // ===============================
    class Base
    {
        public virtual void Print() => Console.WriteLine("Base 클래스 인스턴스");
    }

    class Derived : Base
    {
        public override void Print() => Console.WriteLine("Derived 클래스 인스턴스");
    }

    class BaseArray<U> where U : Base
    {
        public U[] Array { get; set; }

        public BaseArray(int size)
        {
            Array = new U[size];
            Console.WriteLine($"[BaseArray<{typeof(U).Name}>] 생성됨 (크기 {size})");
        }

        public void CopyArray<T>(T[] Target) where T : U
        {
            Console.WriteLine($"[CopyArray] {typeof(T).Name}[] → {typeof(U).Name}[] 복사 시작...");
            Target.CopyTo(Array, 0);
            Console.WriteLine($"[CopyArray] 복사 완료!");
        }
    }

    // ===============================
    // 4️⃣ 매개변수 제약: new() (기본 생성자 필요)
    // ===============================
    internal class MainApp
    {
        public static T CreateInstance<T>() where T : new()
        {
            Console.WriteLine($"[CreateInstance] {typeof(T).Name} 인스턴스 생성됨");
            return new T();
        }

        // ===============================
        // 5️⃣ 인터페이스 제약 (추가)
        // ===============================
        interface IMyInterface
        {
            void Display();
        }

        class MyClass : IMyInterface
        {
            public void Display()
            {
                Console.WriteLine("[MyClass] IMyInterface.Display() 호출됨");
            }
        }

        class InterfaceArray<T> where T : IMyInterface
        {
            public T[] Array { get; set; }

            public InterfaceArray(int size)
            {
                Array = new T[size];
                Console.WriteLine($"[InterfaceArray<{typeof(T).Name}>] 생성됨 (크기 {size})");
            }

            public void ShowAll()
            {
                Console.WriteLine("[InterfaceArray] 배열의 모든 요소 출력:");
                foreach (var item in Array)
                {
                    item?.Display();
                }
            }
        }

        // ===============================
        // 6️⃣ 메인 실행
        // ===============================
        static void Main(string[] args)
        {
            Console.WriteLine("===== StructArray 테스트 =====");
            StructArray<int> a = new StructArray<int>(3);
            a.Array[0] = 0;
            a.Array[1] = 1;
            a.Array[2] = 2;
            Console.WriteLine("StructArray<int> 값:");
            foreach (var item in a.Array)
                Console.WriteLine($"  {item}");
            Console.WriteLine();

            Console.WriteLine("===== RefArray 테스트 =====");
            RefArray<StructArray<double>> b = new RefArray<StructArray<double>>(3);
            b.Array[0] = new StructArray<double>(5);
            b.Array[1] = new StructArray<double>(10);
            b.Array[2] = new StructArray<double>(1005);
            Console.WriteLine("RefArray<StructArray<double>> 생성 완료\n");

            Console.WriteLine("===== BaseArray 테스트 =====");
            BaseArray<Base> c = new BaseArray<Base>(3);
            c.Array[0] = new Base();
            c.Array[1] = new Derived();
            c.Array[2] = CreateInstance<Base>();
            Console.WriteLine("BaseArray<Base> 배열 내용:");
            foreach (var obj in c.Array)
                obj.Print();
            Console.WriteLine();

            Console.WriteLine("===== BaseArray<Derived> 테스트 =====");
            BaseArray<Derived> d = new BaseArray<Derived>(3);
            d.Array[0] = new Derived();
            d.Array[1] = CreateInstance<Derived>();
            d.Array[2] = CreateInstance<Derived>();
            Console.WriteLine("BaseArray<Derived> 배열 내용:");
            foreach (var obj in d.Array)
                obj.Print();
            Console.WriteLine();

            Console.WriteLine("===== CopyArray 테스트 =====");
            BaseArray<Derived> e = new BaseArray<Derived>(3);
            e.CopyArray<Derived>(d.Array);
            Console.WriteLine();

            Console.WriteLine("===== 인터페이스 제약 테스트 =====");
            InterfaceArray<MyClass> f = new InterfaceArray<MyClass>(2);
            f.Array[0] = new MyClass();
            f.Array[1] = CreateInstance<MyClass>();
            f.ShowAll();

            Console.WriteLine("\n=== 프로그램 종료 ===");
        }
    }
}
