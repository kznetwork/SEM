﻿using System;

namespace ArrayFiltering
{
    internal class MainApp
    {
        // TODO: 조건을 만족하는 요소만 반환하는 일반화 메서드
        static T[] Filter<T>(T[] array, Func<T, bool> predicate)
        {
            System.Collections.Generic.List<T> result =
                new System.Collections.Generic.List<T>();

            foreach (T item in array)
            {
                if (predicate(item))
                    result.Add(item);
            }

            return result.ToArray();
        }
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            // 짝수만 필터링
            int[] evens = Filter(numbers, n => n % 2 == 0);
            Console.WriteLine(string.Join(", ", evens));  // 2, 4, 6, 8, 10

            // 5보다 큰 수
            int[] greaterThan5 = Filter(numbers, n => n > 5);
            Console.WriteLine(string.Join(", ", greaterThan5));  // 6, 7, 8, 9, 10

            string[] names = { "Alice", "Bob", "Charlie", "David" };
            // 길이가 5 이상인 이름
            string[] longNames = Filter(names, s => s.Length >= 5);
            Console.WriteLine(string.Join(", ", longNames));  // Alice, Charlie, David
        }
    }
}
