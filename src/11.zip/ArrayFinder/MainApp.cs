﻿using System;

namespace ArrayFinder
{
    internal class MainApp
    {
        // TODO: 배열에서 특정 값을 찾아 인덱스를 반환하는 일반화 메서드 작성
        // 찾지 못하면 -1 반환
        static int FindIndex<T>(T[] array, T value)
        {
            // 구현하세요
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i].Equals(value))
                    return i;
            }
            return -1;
        }
        static void Main(string[] args)
        {
            int[] numbers = { 10, 20, 30, 40, 50 };
            string[] fruits = { "사과", "바나나", "포도", "딸기" };

            Console.WriteLine(FindIndex(numbers, 30));      // 2
            Console.WriteLine(FindIndex(numbers, 100));     // -1
            Console.WriteLine(FindIndex(fruits, "포도"));    // 2
            Console.WriteLine(FindIndex(fruits, "수박"));    // -1
        }
    }
}
