﻿using System;

namespace Constraints_ex2
{
    public class Factory<T> where T : class, new()
    {
        public T CreateInstance()
        {
            return new T();  // new() 제약이 있어야 사용 가능
        }

        public T[] CreateArray(int count)
        {
            T[] array = new T[count];
            for (int i = 0; i < count; i++)
            {
                array[i] = new T();
            }
            return array;
        }
    }

    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public Person()  // 매개변수 없는 생성자 필요
        {
            Name = "Unknown";
            Age = 0;
        }
    }
    internal class MainApp
    {
        static void Main(string[] args)
        {
            Factory<Person> factory = new Factory<Person>();

            Person p1 = factory.CreateInstance();
            Console.WriteLine($"{p1.Name}, {p1.Age}");

            Person[] people = factory.CreateArray(3);
            Console.WriteLine($"생성된 인스턴스 수: {people.Length}");
        }
    }
}
