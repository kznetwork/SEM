﻿using System;

namespace Constraints_ex3
{
    // 비교 가능한 타입만 허용
    public class Sorter<T> where T : IComparable<T>
    {
        public void Sort(T[] array)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                for (int j = 0; j < array.Length - 1 - i; j++)
                {
                    if (array[j].CompareTo(array[j + 1]) > 0)
                    {
                        T temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }

        public T FindMin(T[] array)
        {
            if (array.Length == 0)
                throw new ArgumentException("배열이 비어있습니다.");

            T min = array[0];
            foreach (T item in array)
            {
                if (item.CompareTo(min) < 0)
                    min = item;
            }
            return min;
        }
    }
    internal class MainApp
    {
        static void Main(string[] args)
        {
            Sorter<int> intSorter = new Sorter<int>();
            int[] numbers = { 5, 2, 8, 1, 9 };

            intSorter.Sort(numbers);
            Console.WriteLine(string.Join(", ", numbers));  // 1, 2, 5, 8, 9

            Sorter<string> stringSorter = new Sorter<string>();
            string[] names = { "Charlie", "Alice", "Bob" };

            Console.WriteLine($"최소값: {stringSorter.FindMin(names)}");  // Alice
        }
    }
}
