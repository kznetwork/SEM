﻿using System;

namespace SafeType
{
    // TODO: IComparable 제약을 사용하여 MinMax 클래스 구현
    public class MinMax<T> where T : IComparable<T>
    {
        private T[] data;

        public MinMax(T[] array)
        {
            if (array == null || array.Length == 0)
                throw new ArgumentException("배열이 비어있습니다.");

            data = new T[array.Length];
            Array.Copy(array, data, array.Length);
        }

        public T GetMin()
        {
            T min = data[0];
            foreach (T item in data)
            {
                if (item.CompareTo(min) < 0)
                    min = item;
            }
            return min;
        }

        public T GetMax()
        {
            T max = data[0];
            foreach (T item in data)
            {
                if (item.CompareTo(max) > 0)
                    max = item;
            }
            return max;
        }
    }
    internal class MainApp
    {
        static void Main(string[] args)
        {
            int[] numbers = { 5, 2, 8, 1, 9, 3 };
            MinMax<int> mm = new MinMax<int>(numbers);

            Console.WriteLine($"최소값: {mm.GetMin()}");  // 1
            Console.WriteLine($"최대값: {mm.GetMax()}");  // 9

            string[] names = { "Charlie", "Alice", "Bob" };
            MinMax<string> mmString = new MinMax<string>(names);

            Console.WriteLine($"최소값: {mmString.GetMin()}");  // Alice
            Console.WriteLine($"최대값: {mmString.GetMax()}");  // Charlie
        }
    }
}
