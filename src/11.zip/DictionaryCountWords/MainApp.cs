﻿using System.Collections.Generic;
using System;

namespace DictionaryCountWords
{
    internal class MainApp
    {
        // TODO: Dictionary를 사용하여 단어 빈도수 계산
        static Dictionary<string, int> CountWords(string text)
        {
            Dictionary<string, int> wordCount = new Dictionary<string, int>();
            string[] words = text.Split(' ');

            foreach (string word in words)
            {
                if (wordCount.ContainsKey(word))
                {
                    wordCount[word]++;
                }
                else
                {
                    wordCount[word] = 1;
                }
            }

            return wordCount;
        }
        static void Main(string[] args)
        {
            string text = "apple banana apple orange banana apple grape orange";

            Dictionary<string, int> wordCount = CountWords(text);

            Console.WriteLine("=== 단어 빈도수 ===");
            foreach (var pair in wordCount)
            {
                Console.WriteLine($"{pair.Key}: {pair.Value}회");
            }

            // 예상 출력:
            // apple: 3회
            // banana: 2회
            // orange: 2회
            // grape: 1회
        }
    }
}
