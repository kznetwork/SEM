﻿using System;

namespace Constraints_ex1
{
    public class Calculator<T> where T : struct
    {
        public T Add(T a, T b)
        {
            // dynamic을 사용한 연산 (실무에서는 더 정교한 방법 사용)
            dynamic da = a;
            dynamic db = b;
            return da + db;
        }
    }
    internal class MainApp
    {
        static void Main(string[] args)
        {
            Calculator<int> intCalc = new Calculator<int>();
            Console.WriteLine(intCalc.Add(10, 20));  // 30

            Calculator<double> doubleCalc = new Calculator<double>();
            Console.WriteLine(doubleCalc.Add(3.14, 2.86));  // 6.0

            // Calculator<string> stringCalc = new Calculator<string>();  
            // 컴파일 오류! string은 참조 타입
        }
    }
}
