﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class MainApp : Form
    {
        Button[] btnNums = new Button[10];
        int[] val = new int[2];
        int step, result;
        string oper;

        public MainApp()
        {
            InitializeComponent();

            for (int n = 0; n < btnNums.Length; n++)
            {
                int m = 9 - n;
                btnNums[n] = new Button();
                btnNums[n].Text = n.ToString();
                btnNums[n].Size = new Size(50, 50);
                btnNums[n].Location = new Point(124 - ((m - (((int)(m / 3)) * 3)) * btnNums[n].Width) - ((m - (((int)(m / 3)) * 3)) * 6) - ((int)(m / 9) * 112), (((int)(m / 3)) * btnNums[n].Height) + (((int)(m / 3)) * 6) + 90);
                btnNums[n].Tag = n;
                btnNums[n].Click += new EventHandler(btnNums_Click);

                this.Controls.Add(btnNums[n]);
            }
        }

        void btnNums_Click(object sender, EventArgs e)
        {
            Button btnNum = sender as Button;
            int index = (int)btnNum.Tag;

            if (laDisplay.Text == "0" || result != 0)
                laDisplay.Text = index.ToString();
            else
                laDisplay.Text += index.ToString();
        }

        private void btnCalculates_Click(object sender, EventArgs e)
        {
            Button btnCal = sender as Button;
            string tag = (string)btnCal.Tag;
            result = 0;
            val[step] = int.Parse(laDisplay.Text);
            step = (step + 1) % 3;
            if (tag == "Result" || step >= 2)
            {
                switch (oper)
                {
                    case "Sum":
                        result = val[0] + val[1];
                        break;
                    case "Minus":
                        result = val[0] - val[1];
                        break;
                    case "Multi":
                        result = val[0] * val[1];
                        break;
                    case "Divide":
                        result = val[0] / val[1];
                        break;
                }
                laDisplay.Text = result.ToString();
                step = 0;
            }
            else if (tag == "Clear")
            {
                step = 0;
                laDisplay.Text = (0).ToString();
            }
            else
            {
                laDisplay.Text = (0).ToString();
            }
            oper = tag;
        }
    }
}