﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace UsingControls
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            // 이벤트 연결
            cboFont.SelectedIndexChanged += cboFont_SelectedIndexChanged;
            chkBold.CheckedChanged += chkBold_CheckedChanged;
            chkItalic.CheckedChanged += chkItalic_CheckedChanged;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // 시스템 폰트 목록 불러오기
            foreach (FontFamily font in FontFamily.Families)
                cboFont.Items.Add(font.Name);

            // 콤보박스 초기 설정
            cboFont.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFont.SelectedItem = this.Font.FontFamily.Name;

            ChangeFont();
        }

        private void ChangeFont()
        {
            if (cboFont.SelectedIndex < 0)
                return;

            FontStyle style = FontStyle.Regular;

            if (chkBold.Checked)
                style |= FontStyle.Bold;

            if (chkItalic.Checked)
                style |= FontStyle.Italic;

            txtSampleText.Font = new Font((string)cboFont.SelectedItem, 14, style);
        }

        private void cboFont_SelectedIndexChanged(object sender, EventArgs e) => ChangeFont();
        private void chkBold_CheckedChanged(object sender, EventArgs e) => ChangeFont();
        private void chkItalic_CheckedChanged(object sender, EventArgs e) => ChangeFont();

        private void tbDummy_Scroll(object sender, EventArgs e)
        {
            pgDummy.Value = tbDummy.Value;
        }

        // -----------------------------
        //  Modal / Modeless / MessageBox 버튼
        // -----------------------------

        private void btnModal_Click(object sender, EventArgs e)
        {
            Form frm = new Form();
            frm.Text = "Modal Form";
            frm.Width = 300;
            frm.Height = 100;
            frm.BackColor = Color.Red;
            frm.ShowDialog();   // 모달 방식 (부모 창 제어 불가)
        }

        private void btnModaless_Click(object sender, EventArgs e)
        {
            Form frm = new Form();
            frm.Text = "Modaless Form";
            frm.Width = 300;
            frm.Height = 300;
            frm.BackColor = Color.Green;
            frm.Show();   // 모달리스 방식 (부모 창 제어 가능)
        }

        private void btnMsgBox_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                txtSampleText.Text,
                "MessageBox Test",
                MessageBoxButtons.OK,
                MessageBoxIcon.Exclamation
            );
        }
    }
}
