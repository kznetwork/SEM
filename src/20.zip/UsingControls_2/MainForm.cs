﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace UsingControls
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            // 이벤트 연결
            cboFont.SelectedIndexChanged += cboFont_SelectedIndexChanged;
            chkBold.CheckedChanged += chkBold_CheckedChanged;
            chkItalic.CheckedChanged += chkItalic_CheckedChanged;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // 폰트 목록 불러오기
            foreach (FontFamily font in FontFamily.Families)
                cboFont.Items.Add(font.Name);

            // 기본 콤보박스 설정
            cboFont.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFont.SelectedItem = this.Font.FontFamily.Name;

            ChangeFont();
        }

        private void ChangeFont()
        {
            if (cboFont.SelectedIndex < 0)
                return;

            FontStyle style = FontStyle.Regular;
            if (chkBold.Checked)
                style |= FontStyle.Bold;
            if (chkItalic.Checked)
                style |= FontStyle.Italic;

            txtSampleText.Font = new Font((string)cboFont.SelectedItem, 14, style);
        }

        private void cboFont_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChangeFont();
        }

        private void chkBold_CheckedChanged(object sender, EventArgs e)
        {
            ChangeFont();
        }

        private void chkItalic_CheckedChanged(object sender, EventArgs e)
        {
            ChangeFont();
        }

        private void tbDummy_Scroll(object sender, EventArgs e)
        {
            pgDummy.Value = tbDummy.Value;
        }
    }
}
