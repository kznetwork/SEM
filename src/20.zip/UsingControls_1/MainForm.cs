﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace UsingControls
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            //  이벤트 연결
            cboFont.SelectedIndexChanged += cboFont_SelectedIndexChanged;
            chkBold.CheckedChanged += chkBold_CheckedChanged;
            chkItalic.CheckedChanged += chkItalic_CheckedChanged;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // 폰트 목록 불러오기
            foreach (FontFamily font in FontFamily.Families)
                cboFont.Items.Add(font.Name);

            //  콤보박스 기본 선택값 설정
            cboFont.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFont.SelectedItem = this.Font.FontFamily.Name;

            // 초기 텍스트 박스 폰트 설정
            ChangeFont();
        }

        private void ChangeFont()
        {
            if (cboFont.SelectedIndex < 0)
                return;

            //  폰트 스타일 설정
            FontStyle style = FontStyle.Regular;
            if (chkBold.Checked)
                style |= FontStyle.Bold;
            if (chkItalic.Checked)
                style |= FontStyle.Italic;

            //  텍스트 박스 폰트 적용
            txtSampleText.Font = new Font((string)cboFont.SelectedItem, 14, style);
        }

        //  이벤트 핸들러
        private void cboFont_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChangeFont();
        }

        private void chkBold_CheckedChanged(object sender, EventArgs e)
        {
            ChangeFont();
        }

        private void chkItalic_CheckedChanged(object sender, EventArgs e)
        {
            ChangeFont();
        }
    }
}
