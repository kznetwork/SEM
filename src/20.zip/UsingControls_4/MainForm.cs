﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace UsingControls
{
    public partial class MainForm : Form
    {
        private Random random = new Random(37);

        public MainForm()
        {
            InitializeComponent();

            // 이벤트 연결
            cboFont.SelectedIndexChanged += cboFont_SelectedIndexChanged;
            chkBold.CheckedChanged += chkBold_CheckedChanged;
            chkItalic.CheckedChanged += chkItalic_CheckedChanged;

            // ListView 컬럼 설정
            lvDummy.Columns.Add("Name", 120);
            lvDummy.Columns.Add("Depth", 80);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // 시스템 폰트 목록 불러오기
            foreach (FontFamily font in FontFamily.Families)
                cboFont.Items.Add(font.Name);

            cboFont.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFont.SelectedItem = this.Font.FontFamily.Name;

            ChangeFont();
        }

        // 🟦 폰트 변경
        private void ChangeFont()
        {
            if (cboFont.SelectedIndex < 0)
                return;

            FontStyle style = FontStyle.Regular;

            if (chkBold.Checked)
                style |= FontStyle.Bold;
            if (chkItalic.Checked)
                style |= FontStyle.Italic;

            txtSampleText.Font = new Font((string)cboFont.SelectedItem, 14, style);
        }

        private void cboFont_SelectedIndexChanged(object sender, EventArgs e) => ChangeFont();
        private void chkBold_CheckedChanged(object sender, EventArgs e) => ChangeFont();
        private void chkItalic_CheckedChanged(object sender, EventArgs e) => ChangeFont();

        // 🟩 TrackBar → ProgressBar 연동
        private void tbDummy_Scroll(object sender, EventArgs e)
        {
            pgDummy.Value = tbDummy.Value;
        }

        // 🟥 Modal / Modaless / MessageBox
        private void btnModal_Click(object sender, EventArgs e)
        {
            Form frm = new Form();
            frm.Text = "Modal Form";
            frm.Width = 300;
            frm.Height = 100;
            frm.BackColor = Color.Red;
            frm.ShowDialog();
        }

        private void btnModaless_Click(object sender, EventArgs e)
        {
            Form frm = new Form();
            frm.Text = "Modaless Form";
            frm.Width = 300;
            frm.Height = 300;
            frm.BackColor = Color.Green;
            frm.Show();
        }

        private void btnMsgBox_Click(object sender, EventArgs e)
        {
            MessageBox.Show(txtSampleText.Text,
                "MessageBox Test", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // 🟨 TreeView + ListView
        private void btnAddRoot_Click(object sender, EventArgs e)
        {
            tvDummy.Nodes.Add(random.Next().ToString());
            TreeToList();
        }

        private void btnAddChild_Click(object sender, EventArgs e)
        {
            if (tvDummy.SelectedNode == null)
            {
                MessageBox.Show("선택된 노드가 없습니다.",
                    "TreeView Test", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            tvDummy.SelectedNode.Nodes.Add(random.Next().ToString());
            tvDummy.SelectedNode.Expand();
            TreeToList();
        }

        private void TreeToList()
        {
            lvDummy.Items.Clear();
            foreach (TreeNode node in tvDummy.Nodes)
                TreeToList(node);
        }

        private void TreeToList(TreeNode node)
        {
            lvDummy.Items.Add(new ListViewItem(new string[]
            {
                node.Text,
                node.FullPath.Count(f => f == '\\').ToString()
            }));

            foreach (TreeNode child in node.Nodes)
                TreeToList(child);
        }
    }
}
