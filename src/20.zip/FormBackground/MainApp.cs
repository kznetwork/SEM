﻿/*using System;
using System.Drawing;
using System.Windows.Forms;

namespace FormBackground
{
    class MainApp : Form
    {
        Random rand;
        public MainApp()
        {
            rand = new Random();

            this.MouseWheel += new MouseEventHandler(MainApp_MouseWheel);
            this.MouseDown += new MouseEventHandler(MainApp_MouseDown);
        }

        void MainApp_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Color oldColor = this.BackColor;
                this.BackColor = Color.FromArgb(rand.Next(0, 255),
                                                rand.Next(0, 255),
                                                rand.Next(0, 255));
            }
            else if (e.Button == MouseButtons.Right)
            {
                if (this.BackgroundImage != null)
                {
                    this.BackgroundImage = null;
                    return;
                }

                string file = "sample.jpg";
                if (System.IO.File.Exists(file) == false)
                    MessageBox.Show("이미지 파일이 없습니다.");
                else
                    this.BackgroundImage = Image.FromFile(file);
            }
        }

        void MainApp_MouseWheel(object sender, MouseEventArgs e)
        {
            this.Opacity = this.Opacity + (e.Delta > 0 ? 0.1 : -0.1);
            Console.WriteLine($"Opacity: {this.Opacity}");
        }

        static void Main(string[] args)
        {
            Application.Run(new MainApp());
        }
    }
}*/


using System;
using System.Drawing;
using System.Windows.Forms;

namespace SimpleBackground
{
    public class MainApp : Form
    {
        Image background;

        public MainApp()
        {
            // Cosmos.jpg 불러오기
            string file = "Cosmos.jpg";
            if (!System.IO.File.Exists(file))
            {
                MessageBox.Show("이미지 파일을 찾을 수 없습니다: " + System.IO.Path.GetFullPath(file));
                Environment.Exit(0);
            }

            background = Image.FromFile(file);

            // 폼 크기를 이미지 크기에 맞게 설정
            this.ClientSize = background.Size;
            this.Text = "Original Size Background Example";
            this.DoubleBuffered = true; // 깜빡임 방지
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // 이미지 원본 크기 그대로 (좌측 상단 기준) 그리기
            e.Graphics.DrawImage(background, 0, 0, background.Width, background.Height);
        }

        [STAThread]
        static void Main()
        {
            Application.Run(new MainApp());
        }
    }
}
