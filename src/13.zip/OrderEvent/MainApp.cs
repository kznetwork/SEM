﻿using System;

namespace OrderEvent
{
    class OrderEventArgs : EventArgs
    {
        public int OrderId { get; set; }
        public string CustomerName { get; set; }
        public decimal Amount { get; set; }
    }

    class OrderProcessor
    {
        // 이벤트 선언
        public event EventHandler<OrderEventArgs> OrderReceived;
        public event EventHandler<OrderEventArgs> OrderProcessed;
        public event EventHandler<OrderEventArgs> OrderShipped;
        public event EventHandler<OrderEventArgs> OrderCancelled;

        public void ProcessOrder(int orderId, string customerName, decimal amount)
        {
            var args = new OrderEventArgs
            {
                OrderId = orderId,
                CustomerName = customerName,
                Amount = amount
            };

            // 주문 접수
            OnOrderReceived(args);

            // 주문 처리
            System.Threading.Thread.Sleep(500);
            OnOrderProcessed(args);

            // 배송
            System.Threading.Thread.Sleep(500);
            OnOrderShipped(args);
        }

        public void CancelOrder(int orderId, string customerName)
        {
            var args = new OrderEventArgs
            {
                OrderId = orderId,
                CustomerName = customerName
            };

            OnOrderCancelled(args);
        }

        protected virtual void OnOrderReceived(OrderEventArgs e)
        {
            OrderReceived?.Invoke(this, e);
        }

        protected virtual void OnOrderProcessed(OrderEventArgs e)
        {
            OrderProcessed?.Invoke(this, e);
        }

        protected virtual void OnOrderShipped(OrderEventArgs e)
        {
            OrderShipped?.Invoke(this, e);
        }

        protected virtual void OnOrderCancelled(OrderEventArgs e)
        {
            OrderCancelled?.Invoke(this, e);
        }
    }

    // 알림 서비스
    class NotificationService
    {
        public void Subscribe(OrderProcessor processor)
        {
            processor.OrderReceived += OnOrderReceived;
            processor.OrderProcessed += OnOrderProcessed;
            processor.OrderShipped += OnOrderShipped;
            processor.OrderCancelled += OnOrderCancelled;
        }

        private void OnOrderReceived(object sender, OrderEventArgs e)
        {
            Console.WriteLine($"[알림] 주문 #{e.OrderId} 접수됨 - {e.CustomerName}");
        }

        private void OnOrderProcessed(object sender, OrderEventArgs e)
        {
            Console.WriteLine($"[알림] 주문 #{e.OrderId} 처리 완료");
        }

        private void OnOrderShipped(object sender, OrderEventArgs e)
        {
            Console.WriteLine($"[알림] 주문 #{e.OrderId} 배송 시작");
        }

        private void OnOrderCancelled(object sender, OrderEventArgs e)
        {
            Console.WriteLine($"[알림] 주문 #{e.OrderId} 취소됨");
        }
    }

    // 로깅 서비스
    class LoggingService
    {
        public void Subscribe(OrderProcessor processor)
        {
            processor.OrderReceived += Log;
            processor.OrderProcessed += Log;
            processor.OrderShipped += Log;
            processor.OrderCancelled += Log;
        }

        private void Log(object sender, OrderEventArgs e)
        {
            Console.WriteLine($"[로그] {DateTime.Now:HH:mm:ss} - 주문 #{e.OrderId}, " +
                             $"고객: {e.CustomerName}, 금액: {e.Amount:C}");
        }
    }
    internal class MainApp
    {
        static void Main(string[] args)
        {
            OrderProcessor processor = new OrderProcessor();

            // 서비스 등록
            NotificationService notification = new NotificationService();
            notification.Subscribe(processor);

            LoggingService logging = new LoggingService();
            logging.Subscribe(processor);

            // 주문 처리
            Console.WriteLine("=== 주문 1 ===");
            processor.ProcessOrder(1001, "홍길동", 50000);

            Console.WriteLine("\n=== 주문 2 ===");
            processor.ProcessOrder(1002, "김철수", 120000);

            Console.WriteLine("\n=== 주문 취소 ===");
            processor.CancelOrder(1003, "이영희");
        }
    }
}
