﻿using System;

namespace CalculatorwithDelegate
{
    // TODO: 계산 대리자 선언
    delegate double Calculator(double a, double b);
    internal class MainApp
    {
        // TODO: 계산 메서드들 구현
        static double Add(double a, double b)
        {
            return a + b;
        }

        static double Subtract(double a, double b)
        {
            return a - b;
        }

        static double Multiply(double a, double b)
        {
            return a * b;
        }

        static double Divide(double a, double b)
        {
            if (b == 0)
                throw new DivideByZeroException("0으로 나눌 수 없습니다.");
            return a / b;
        }

        // TODO: 대리자를 사용하는 계산 메서드
        static void Calculate(double a, double b, Calculator calc, string operation)
        {
            try
            {
                double result = calc(a, b);
                Console.WriteLine($"{a} {operation} {b} = {result}");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine($"{a} {operation} {b} = 오류: {ex.Message}");
            }
        }

        static void Main(string[] args)
        {
            Calculate(10, 5, Add, "+");
            Calculate(10, 5, Subtract, "-");
            Calculate(10, 5, Multiply, "*");
            Calculate(10, 5, Divide, "/");
            Calculate(10, 0, Divide, "/");  // 예외 처리 확인
        }
    }
}
