﻿using System;

namespace TemperatureEvent
{
    class TemperatureEventArgs : EventArgs
    {
        public double Temperature { get; set; }
        public DateTime Timestamp { get; set; }
    }

    class TemperatureSensor
    {
        private double currentTemperature;

        public event EventHandler<TemperatureEventArgs> TemperatureChanged;
        public event EventHandler<TemperatureEventArgs> HighTemperatureAlert;
        public event EventHandler<TemperatureEventArgs> LowTemperatureAlert;

        public double CurrentTemperature
        {
            get { return currentTemperature; }
            set
            {
                currentTemperature = value;

                var args = new TemperatureEventArgs
                {
                    Temperature = currentTemperature,
                    Timestamp = DateTime.Now
                };

                OnTemperatureChanged(args);

                if (currentTemperature >= 30)
                {
                    OnHighTemperatureAlert(args);
                }
                else if (currentTemperature <= 0)
                {
                    OnLowTemperatureAlert(args);
                }
            }
        }

        protected virtual void OnTemperatureChanged(TemperatureEventArgs e)
        {
            TemperatureChanged?.Invoke(this, e);
        }

        protected virtual void OnHighTemperatureAlert(TemperatureEventArgs e)
        {
            HighTemperatureAlert?.Invoke(this, e);
        }

        protected virtual void OnLowTemperatureAlert(TemperatureEventArgs e)
        {
            LowTemperatureAlert?.Invoke(this, e);
        }
    }
    internal class MainApp
    {
        static void Main(string[] args)
        {
            TemperatureSensor sensor = new TemperatureSensor();

            // TODO: 이벤트 구독
            sensor.TemperatureChanged += (sender, e) =>
            {
                Console.WriteLine($"[{e.Timestamp:HH:mm:ss}] 온도: {e.Temperature}°C");
            };

            sensor.HighTemperatureAlert += (sender, e) =>
            {
                Console.WriteLine($"⚠ 경고! 고온: {e.Temperature}°C");
            };

            sensor.LowTemperatureAlert += (sender, e) =>
            {
                Console.WriteLine($"⚠ 경고! 저온: {e.Temperature}°C");
            };

            // 온도 변경 테스트
            sensor.CurrentTemperature = 25;
            sensor.CurrentTemperature = 35;  // 고온 경고
            sensor.CurrentTemperature = -5;  // 저온 경고
            sensor.CurrentTemperature = 20;
        }
    }
}
