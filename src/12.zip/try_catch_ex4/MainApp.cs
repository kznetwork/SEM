﻿using System;

namespace try_catch_ex4
{
    class Calculator
    {
        // TODO: 예외 처리를 적용한 안전한 나눗셈 메서드
        public static double SafeDivide(double a, double b)
        {
            try
            {
                return a / b;
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("오류: 0으로 나눌 수 없습니다.");
                return 0;
            }
        }

        // TODO: 배열 접근을 안전하게 처리하는 메서드
        public static int SafeGetElement(int[] array, int index)
        {
            try
            {
                if (array == null)
                {
                    Console.WriteLine("오류: 배열이 null입니다.");
                    return -1;
                }
                return array[index];
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine($"오류: 인덱스 {index}가 범위를 벗어났습니다.");
                return -1;
            }
        }
    }

    internal class MainApp
    {
        static void Main(string[] args)
        {// 나눗셈 테스트
            Console.WriteLine(Calculator.SafeDivide(10, 2));   // 5
            Console.WriteLine(Calculator.SafeDivide(10, 0));   // 예외 처리 후 0

            // 배열 접근 테스트
            int[] numbers = { 10, 20, 30, 40, 50 };
            Console.WriteLine(Calculator.SafeGetElement(numbers, 2));   // 30
            Console.WriteLine(Calculator.SafeGetElement(numbers, 10));  // 예외 처리 후 -1
            Console.WriteLine(Calculator.SafeGetElement(null, 0));      // 예외 처리 후 -1
        }
    }
}
