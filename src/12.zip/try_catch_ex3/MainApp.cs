﻿using System.IO;
using System;

namespace try_catch_ex3
{
    internal class MainApp
    {
        static void Main(string[] args)
        {
            StreamReader reader = null;

            try
            {
                reader = new StreamReader("data.txt");
                string content = reader.ReadToEnd();
                Console.WriteLine(content);
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("파일을 찾을 수 없습니다.");
            }
            finally
            {
                // 예외 발생 여부와 관계없이 항상 실행
                if (reader != null)
                {
                    reader.Close();
                    Console.WriteLine("파일이 닫혔습니다.");
                }
            }
        }
    }
}
