﻿using System;

namespace try_catch_ex2
{
    internal class MainApp
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("나눗셈 - 첫 번째 숫자: ");
                int num1 = int.Parse(Console.ReadLine());

                Console.Write("나눗셈 - 두 번째 숫자: ");
                int num2 = int.Parse(Console.ReadLine());

                int result = num1 / num2;
                Console.WriteLine($"결과: {result}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine("오류: 숫자를 입력해야 합니다.");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("오류: 0으로 나눌 수 없습니다.");
            }
            catch (Exception ex)  // 가장 일반적인 예외 (마지막에 배치)
            {
                Console.WriteLine($"예상치 못한 오류: {ex.Message}");
            }
        }
    }
}
