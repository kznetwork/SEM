﻿using System;

namespace try_catch_ex1
{
    internal class MainApp
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("숫자를 입력하세요: ");
                string input = Console.ReadLine();
                int number = int.Parse(input);

                Console.WriteLine($"입력한 숫자: {number}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine("오류: 올바른 숫자 형식이 아닙니다.");
                Console.WriteLine($"예외 메시지: {ex.Message}");
            }

            Console.WriteLine("프로그램 계속 실행...");  // 정상 실행됨!
        }
    }
}
