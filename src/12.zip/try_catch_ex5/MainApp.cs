﻿using System;

namespace try_catch_ex5
{
    internal class MainApp
    {
        static void SetAge(int age)
        {
            // ArgumentOutOfRangeException
            if (age < 0 || age > 150)
            {
                throw new ArgumentOutOfRangeException(nameof(age),
                    "나이는 0~150 사이여야 합니다.");
            }
        }

        static void SetName(string name)
        {
            // ArgumentNullException
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name),
                    "이름은 null일 수 없습니다.");
            }

            // ArgumentException
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("이름은 공백일 수 없습니다.", nameof(name));
            }
        }
        static void Main(string[] args)
        {
            try
            {
                SetAge(200);
            }
            catch (ArgumentOutOfRangeException ex)
            {
                Console.WriteLine($"오류: {ex.Message}");
                Console.WriteLine($"매개변수: {ex.ParamName}");
            }

            try
            {
                SetName(null);
            }
            catch (ArgumentNullException ex)
            {
                Console.WriteLine($"오류: {ex.Message}");
            }
        }
    }
}
