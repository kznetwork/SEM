﻿using System;

namespace UserRegistrationSystem
{
    class User
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }
    }

    class UserValidator
    {
        // TODO: 사용자 유효성 검사 메서드
        public static void Validate(User user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user), "사용자 객체가 null입니다.");
            }

            if (string.IsNullOrWhiteSpace(user.Username))
            {
                throw new ArgumentException("사용자 이름은 필수입니다.", nameof(user.Username));
            }

            if (user.Username.Length < 3)
            {
                throw new ArgumentException("사용자 이름은 3자 이상이어야 합니다.",
                    nameof(user.Username));
            }

            if (string.IsNullOrWhiteSpace(user.Email) || !user.Email.Contains("@"))
            {
                throw new ArgumentException("올바른 이메일 주소가 아닙니다.", nameof(user.Email));
            }

            if (user.Age < 0 || user.Age > 120)
            {
                throw new ArgumentOutOfRangeException(nameof(user.Age),
                    "나이는 0~120 사이여야 합니다.");
            }
        }
    }
    internal class MainApp
    {
        static void Main(string[] args)
        {
            // 테스트 케이스
            User[] testUsers =
            {
            null,
            new User { Username = "ab", Email = "test@example.com", Age = 25 },
            new User { Username = "john", Email = "invalid-email", Age = 25 },
            new User { Username = "john", Email = "john@example.com", Age = 150 },
            new User { Username = "john", Email = "john@example.com", Age = 25 }
        };

            foreach (var user in testUsers)
            {
                try
                {
                    Console.WriteLine("\n사용자 검증 중...");
                    UserValidator.Validate(user);
                    Console.WriteLine($"✓ 검증 성공: {user.Username}");
                }
                catch (ArgumentNullException ex)
                {
                    Console.WriteLine($"✗ Null 오류: {ex.Message}");
                }
                catch (ArgumentOutOfRangeException ex)
                {
                    Console.WriteLine($"✗ 범위 오류: {ex.Message}");
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"✗ 유효성 오류: {ex.Message}");
                }
            }
        }
    }
}
